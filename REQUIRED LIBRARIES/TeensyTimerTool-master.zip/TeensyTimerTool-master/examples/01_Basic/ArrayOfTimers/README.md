Measured output of the example sketch

![Output](./../../assets/FTM0_8CH.jpg)