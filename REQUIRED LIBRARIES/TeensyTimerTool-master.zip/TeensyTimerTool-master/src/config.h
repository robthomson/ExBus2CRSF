#pragma once

#if __has_include("userConfig.h")
    #include "userConfig.h"
#else
    #include "defaultConfig.h"
#endif
